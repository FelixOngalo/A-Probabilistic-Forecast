# Customer Lifetime Value: A Probabilistic Forecast

**Question:** *(fill in)* How much revenue will each customer generate in the next 90 days, and which customers are worth prioritizing for retention spend?

**Key findings:** *(fill in after running; total predicted 90-day revenue, validation ratio, and your recommendation)*

**Tools:** R, `BTYD` (BG/NBD and Gamma-Gamma models), tidyverse, Quarto

## Why this project — and how it differs from the RFM segmentation project

This portfolio already has an RFM segmentation project (`sales-analytics-dashboard`), which buckets customers by past behavior. This project is a genuinely different technique: a **forward-looking probabilistic forecast**. Instead of describing what customers have done, BG/NBD and Gamma-Gamma predict what they're likely to do next — a specific number of future transactions and future revenue per customer, with each prediction backed by an underlying statistical model of purchase and churn behavior rather than a quartile cutoff.

## Reproduce

1. Download the "Online Retail II" dataset to `data/raw/online_retail_II.xlsx` (see `R/00_get_data.R`) — reuse the file from the sales-analytics-dashboard project if you already have it
2. `install.packages(c("BTYD", "tidyverse", "janitor", "readxl", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_fit_models.R` (fits BG/NBD + Gamma-Gamma, produces the CLV forecast)
   - `R/03_validate_model.R` (calibration/holdout validation)
   - Render `reports/report.qmd`

## Method in brief

1. **Reshape transactions into customer-level summary statistics** (frequency, recency, T, monetary value) — the specific format these models require, which differs subtly from ordinary RFM (see `R/clv_functions.R` for the exact definitions and why they differ).
2. **Fit BG/NBD** to model how many future transactions each customer will make, based on two population-level assumptions: a personal purchase rate, and a probability of silently churning after any purchase.
3. **Fit Gamma-Gamma** to model each customer's expected spend per transaction, assuming it's independent of purchase frequency (checked, not assumed, in the report).
4. **Combine the two** into an expected-revenue forecast per customer over a chosen horizon.
5. **Validate honestly**: fit on an earlier calibration period, then compare the model's forecast for a later holdout period against what customers actually did — the same train/test logic as the churn-prediction project, applied to a forecasting model.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| BG/NBD | A model predicting number of future transactions, assuming customers purchase at a steady personal rate until they silently "die" (stop) |
| Gamma-Gamma | A model predicting average transaction value, assumed independent of purchase frequency |
| P(alive) | The model's estimated probability a customer is still an active (non-churned) customer |
| Frequency (BTYD sense) | Number of REPEAT transactions — the first purchase is excluded, since it defines the customer rather than counting as a repeat event |
| Calibration / holdout split | Fit the model on an earlier period, check its forecast against a later period it never saw |
| Aggregate calibration | Checking total predicted vs. total actual transactions across all customers — the standard way these models are validated, since individual predictions are expected to be noisy |

## Project structure

```
R/00_get_data.R           data source notes
R/cleaning.R                cleaning function
R/01_clean.R                 run cleaning
R/clv_functions.R            build_cbs() and calibration/holdout split functions (heavily commented)
R/02_fit_models.R             fit BG/NBD + Gamma-Gamma, produce the CLV forecast
R/03_validate_model.R          calibration/holdout validation
reports/report.qmd             full write-up: method, assumption checks, validation, recommendation
```

## Limitations

*(fill in — see the report's own Limitations section: no seasonality modeling, independence assumption, non-discounted CLV)*

# Fit the BG/NBD model (predicts HOW MANY future transactions) and the
# Gamma-Gamma model (predicts HOW MUCH each transaction is worth),
# then combine them into a CLV forecast. Uses the `BTYD` package,
# which expects columns named x, t.x, T.cal, m.x -- we rename from
# our more readable column names right before handing data to it.

library(dplyr)
library(BTYD)
source("R/clv_functions.R")

orders <- readRDS("data/clean/orders_clean.rds")

observation_end <- max(orders$invoice_date)
cbs <- build_cbs(orders, observation_end)

cat("Customers in calibration-ready summary:", nrow(cbs), "\n")
cat("Customers with >=1 repeat purchase:", sum(cbs$frequency > 0), "\n")

# BTYD's functions expect a matrix with these exact column names.
cal_cbs <- cbs |>
  transmute(x = frequency, t.x = recency, T.cal = t_age) |>
  as.matrix()
rownames(cal_cbs) <- cbs$customer_id

# --- BG/NBD: models transaction FREQUENCY ---
# Two behavioral assumptions, which is what makes this better than a
# naive "average purchase rate" projection:
#  1. While "alive," a customer purchases at a steady personal rate,
#     but that rate varies across customers (gamma-distributed).
#  2. After any purchase, a customer may "die" (permanently stop) with
#     some probability, which also varies across customers (beta-dist).
# Fitting fewer than roughly 2 purchases doesn't inform the "death"
# side of the model much, but BG/NBD handles that gracefully via the
# population-level priors -- unlike a per-customer average, it doesn't
# need many transactions from any single person to work.
bgnbd_params <- bgnbd.EstimateParameters(cal_cbs)
names(bgnbd_params) <- c("r", "alpha", "a", "b")
cat("\n=== BG/NBD parameters ===\n")
print(bgnbd_params)

# P(alive): the model's estimate that each customer is still an active
# (non-churned) customer, given their observed purchase pattern.
p_alive <- bgnbd.PAlive(bgnbd_params, cbs$frequency, cbs$recency, cbs$t_age)

# Forecast: expected number of transactions in the NEXT `horizon_days`,
# for each customer, conditional on their history so far.
horizon_days <- 90
expected_transactions <- bgnbd.ConditionalExpectedTransactions(
  bgnbd_params, T.star = horizon_days,
  x = cbs$frequency, t.x = cbs$recency, T.cal = cbs$t_age
)

# --- Gamma-Gamma: models transaction VALUE ---
# Only fit on customers with at least one repeat transaction -- the
# Gamma-Gamma model assumes monetary value is independent of purchase
# frequency, which is only estimable from customers who've made a
# repeat purchase to average over.
repeat_customers <- cbs |> filter(frequency > 0, monetary_value > 0)

spend_params <- spend.EstimateParameters(
  m.x.vector = repeat_customers$monetary_value,
  x.vector   = repeat_customers$frequency
)
names(spend_params) <- c("p", "q", "gamma")
cat("\n=== Gamma-Gamma parameters ===\n")
print(spend_params)

expected_avg_value <- spend.expected.value(
  spend_params, m.x = cbs$monetary_value, x = cbs$frequency
)

# --- Combine into a CLV forecast ---
clv_results <- cbs |>
  mutate(
    p_alive               = p_alive,
    expected_transactions = expected_transactions,
    expected_avg_value    = expected_avg_value,
    predicted_clv_90d      = expected_transactions * expected_avg_value
  ) |>
  arrange(desc(predicted_clv_90d))

saveRDS(list(
  cbs = cbs, bgnbd_params = bgnbd_params, spend_params = spend_params,
  clv_results = clv_results, horizon_days = horizon_days,
  observation_end = observation_end
), "data/clean/clv_model_results.rds")

cat("\n=== Top 10 customers by predicted 90-day CLV ===\n")
print(head(clv_results, 10))

cat("\nTotal predicted 90-day revenue (sum across all customers): ",
    round(sum(clv_results$predicted_clv_90d), 2), "\n")

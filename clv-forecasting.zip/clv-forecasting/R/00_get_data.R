# Data: reuse the "Online Retail II" dataset (same source as the
# sales-analytics-dashboard and market-basket-analysis projects) --
# transaction-level data is exactly what probabilistic CLV models need:
# one row per order, with a customer ID, a date, and an amount.
#   https://archive.ics.uci.edu/dataset/502/online+retail+ii
# Download the XLSX and place it at data/raw/online_retail_II.xlsx
#
# If you already downloaded this for an earlier project, you can reuse
# the same file -- no need to download it twice.
message("Download Online Retail II to data/raw/online_retail_II.xlsx (reuse from earlier projects if you already have it)")

# Validate the BG/NBD model the honest way: fit it on a calibration
# period only, then check whether its forecasts for the holdout period
# match what customers ACTUALLY did -- the same train/test logic used
# in the churn-prediction project, applied to a forecasting model
# instead of a classifier.

library(dplyr)
library(BTYD)
source("R/clv_functions.R")

orders <- readRDS("data/clean/orders_clean.rds")

# Split roughly 80/20 by time: calibrate on the first ~80% of the
# observation window, hold out the last ~20% to check against.
date_range <- range(orders$invoice_date)
total_days <- as.numeric(diff(date_range))
cutoff     <- date_range[1] + round(total_days * 0.8)

cat("Calibration period:", as.character(date_range[1]), "to", as.character(cutoff), "\n")
cat("Holdout period:    ", as.character(cutoff), "to", as.character(date_range[2]), "\n")

split <- split_calibration_holdout(orders, cutoff)
cbs <- split$cbs

cal_cbs <- cbs |>
  transmute(x = frequency, t.x = recency, T.cal = t_age) |>
  as.matrix()
rownames(cal_cbs) <- cbs$customer_id

params <- bgnbd.EstimateParameters(cal_cbs)

holdout_days <- as.numeric(date_range[2] - cutoff)
predicted_holdout <- bgnbd.ConditionalExpectedTransactions(
  params, T.star = holdout_days,
  x = cbs$frequency, t.x = cbs$recency, T.cal = cbs$t_age
)

comparison <- cbs |>
  mutate(predicted_holdout_transactions = predicted_holdout) |>
  left_join(split$holdout_actual, by = "customer_id") |>
  mutate(actual_holdout_transactions = coalesce(actual_holdout_transactions, 0))

# Model accuracy: compare TOTAL predicted vs TOTAL actual transactions
# across all customers -- this is the standard BG/NBD validation check
# (aggregate calibration), since the model is tuned for population-level
# accuracy, not necessarily a perfect per-customer prediction.
total_predicted <- sum(comparison$predicted_holdout_transactions)
total_actual    <- sum(comparison$actual_holdout_transactions)

cat("\n=== Holdout validation ===\n")
cat("Total predicted transactions (holdout):", round(total_predicted, 1), "\n")
cat("Total actual transactions (holdout):   ", total_actual, "\n")
cat("Ratio (predicted / actual):            ", round(total_predicted / total_actual, 3), "\n")

# Per-customer correlation: a secondary check -- does the model at
# least rank customers sensibly, even if individual predictions are noisy?
corr <- cor(comparison$predicted_holdout_transactions, comparison$actual_holdout_transactions)
cat("Correlation (predicted vs actual, per customer):", round(corr, 3), "\n")

saveRDS(comparison, "data/clean/holdout_validation.rds")

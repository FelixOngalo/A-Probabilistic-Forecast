# Reusable functions for probabilistic Customer Lifetime Value (CLV)
# modeling using the BG/NBD and Gamma-Gamma models (via the `BTYD` /
# `CLVTools` packages). These models answer a genuinely different
# question than the RFM segmentation in the sales-analytics-dashboard
# project: not "which quartile is this customer in right now" but
# "how many purchases will this specific customer make in the next
# N days, and how much are they worth, projected forward."

library(dplyr)
library(lubridate)

#' Build the customer-level summary statistics that BG/NBD needs:
#' frequency, recency, T (customer age), and monetary value.
#'
#' These four numbers are DIFFERENT from ordinary RFM:
#'  - frequency = number of REPEAT transactions (first purchase doesn't
#'    count -- it's what defines the customer, not a repeat event)
#'  - recency   = time between the customer's FIRST and LAST purchase
#'    (not "time since last purchase" as in ordinary RFM -- that's a
#'    common point of confusion when moving from RFM to BTYD models)
#'  - T         = time between the customer's first purchase and the
#'    end of the observation period (their total observable "age")
#'  - monetary  = average spend per transaction (excluding the first,
#'    for consistency with the Gamma-Gamma model's assumptions)
#'
#' @param orders Cleaned order-level data with customer_id, invoice_date, revenue.
#' @param observation_end Date marking the end of the observation window
#'   ("today", for modeling purposes). Defaults to the max date in the data.
#' @return A tibble: customer_id, frequency, recency, T, monetary_value.
build_cbs <- function(orders, observation_end = NULL) {
  if (is.null(observation_end)) observation_end <- max(orders$invoice_date)

  customer_orders <- orders |>
    group_by(customer_id, invoice_date) |>
    summarise(order_value = sum(revenue), .groups = "drop") |>
    arrange(customer_id, invoice_date)

  customer_orders |>
    group_by(customer_id) |>
    summarise(
      first_purchase = min(invoice_date),
      last_purchase  = max(invoice_date),
      frequency      = n() - 1,   # repeat transactions only -- first purchase excluded
      recency        = as.numeric(last_purchase - first_purchase),
      t_age          = as.numeric(observation_end - first_purchase),
      monetary_value = if_else(n() > 1,
                               (sum(order_value) - first(order_value)) / (n() - 1),
                               0),
      .groups = "drop"
    ) |>
    filter(t_age >= 0) |>
    select(customer_id, frequency, recency, t_age, monetary_value)
}

#' Split a customer-by-time-period summary into a calibration period
#' (used to fit the model) and a holdout period (used to check its
#' predictions against what customers ACTUALLY did) -- the standard
#' way to validate a BTYD-style model honestly, directly analogous to
#' the train/test split used in the churn-prediction project.
#'
#' @param orders Cleaned order-level data.
#' @param cutoff_date The date splitting calibration from holdout.
#' @return A list with calibration (cbs) and holdout (actual repeat
#'   purchases observed after cutoff_date) data.
split_calibration_holdout <- function(orders, cutoff_date) {
  calib_orders <- orders |> filter(invoice_date <= cutoff_date)
  holdout_orders <- orders |> filter(invoice_date > cutoff_date)

  cbs <- build_cbs(calib_orders, observation_end = cutoff_date)

  holdout_actual <- holdout_orders |>
    distinct(customer_id, invoice_date) |>
    count(customer_id, name = "actual_holdout_transactions")

  list(cbs = cbs, holdout_actual = holdout_actual)
}
